import React, { useEffect } from "react";
import Head from "next/head";
import Script from "next/script";
import { BASEPATH } from "@/config";
import BlogLeftSidebar from "@/components/blog/BlogLeftSidebar";
import BlogRightSidebar from "@/components/blog/BlogRightSidebar";
import dateFormat from 'dateformat';
import Link from "next/link";

export default function PageSingle({AllsinglePageList,}) {
  // console.log("URL", AllsinglePageList);
  

  
  if (AllsinglePageList.data.page !== null) {
    
    return (
      <>
        <Head>
          <title>{AllsinglePageList?.data.page.seo.title}</title>
          <meta name="deScription" content={AllsinglePageList?.data.page.seo.metaDesc} />
          <link rel="canonical" href={`https://www.testbytes.net/${AllsinglePageList?.data.page.slug}`} />
          <meta name="image" property="og:image" content="/images/TestBytes_OG.jpg" />
          <meta property="og:type" content="website" />
          <meta property="og:title" content="Testbytes: Software Testing and QA Consulting Company" />
          <meta property="og:deScription" content="Looking for independent software testing services? Testbytes can offer game testing, mobile app testing, security testing, performance testing, and more." />
          <meta property="og:title" content={AllsinglePageList?.data.page.seo.title} className="yoast-seo-meta-tag" />
          <meta property="og:deScription" content={AllsinglePageList?.data.page.seo.metaDesc} className="yoast-seo-meta-tag" />
          <meta property="og:url" content={`https://www.testbytes.net/${AllsinglePageList?.data.page.slug}`} className="yoast-seo-meta-tag" />
          <meta property="og:site_name" content="Testbytes" className="yoast-seo-meta-tag" />
          
          <link rel="stylesheet" href={`https://testbytesnxtjsbackend.technoallianceindia.com/wp-content/uploads/elementor/css/post-${AllsinglePageList.data.page.pageId}.css`} media="all" />
      
        </Head>

         {console.log("Testing Pages")}
        <div className="innerpages-contentsdata">
          {AllsinglePageList?.data?.page?.content !== null && (
            <div
              dangerouslySetInnerHTML={{
                __html: `${AllsinglePageList?.data?.page?.content}`,
              }}
            ></div>
          )}
        </div>
      </>
    );
  } 
  



}

export async function getStaticPaths() {
  const resourceAPI = await fetch(`${BASEPATH}graphql`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: `
      query NewQuery {
        pages(first: 10) {
          nodes {
            pageId
            slug
            title
          }
        }
      }
             `,
    }),
  });
  const resourceAPIList = await resourceAPI.json();
  const paths = resourceAPIList.data.pages.nodes.map((list) => ({
    params: { pageslug: list.slug },
  }));
  return {
    paths,
    // fallback: "blocking",
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const currentApi = await fetch(`${BASEPATH}graphql`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query: `
          query NewQuery {
              page(
                  id: "${params.pageslug}" ,idType: URI) 
               {
                pageId
                slug
                title
                content
                seo {
                  title
                  metaDesc
                }
               
              }
            }
          `,
    }),
  });

  const AllsinglePageList = await currentApi.json();



  return {
    props: {
      AllsinglePageList,
      
    },
    revalidate: 10,
  };
}
